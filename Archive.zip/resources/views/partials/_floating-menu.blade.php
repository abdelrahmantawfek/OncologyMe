<ul id="social_side_links">
    <li><a style="background-color: #3c5a96;" href="{{$general_info[0]->fb}}" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
    <li><a style="background-color: #FF0000;" href="{{$general_info[0]->youtube}}" target="_blank"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
    <li><a style="background-color: #1178b3;" href="{{$general_info[0]->linkedin}}" target="_blank"><i class="careerfy-bgcolorhover fa fa-linkedin" aria-hidden="true"></i></a></li>
</ul>

<ul class="feedback">
    <li><a href="{{$general_info[0]->feedback}}" target="_blank"><i class="fa fa-file-text-o" aria-hidden="true"></i>  Feedback</a></li>
</ul>