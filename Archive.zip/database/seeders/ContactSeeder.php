<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ContactSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $contacts = array(
        //     array('id' => 1, 'name' => 'Doaa', 'phone' => '01111250257', 'email' => 'doaa@email.com', 'subject' => 'problem', 'message' => 'i faced a problem with the site'),
        //     array('id' => 2, 'name' => 'Ahmed', 'phone' => '01122389416', 'email' => 'ahmed@email.com', 'subject' => 'congratulation', 'message' => 'your site is great'),
        //     array('id' => 3, 'name' => 'Sara', 'phone' => '01147334146', 'email' => 'sara@email.com', 'subject' => 'suggestion', 'message' => 'you can do more effort'),
 
        // );

        // DB::table('contacts')->insert($contacts);
    }
}
