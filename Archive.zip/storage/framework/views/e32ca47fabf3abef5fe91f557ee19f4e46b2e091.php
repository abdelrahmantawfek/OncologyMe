<?php $__env->startSection('meta'); ?>

   
   <title> <?php echo e($data['page']->page_title); ?> - <?php echo e($general_info[0]->tagline); ?>  </title>
   <meta name="title" content="<?php echo e($data['page']->meta_title ?? ''); ?>">
   

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Main Section -->
<div class="careerfy-main-section careerfy-counter-full topics-section scrolly-box">
    <div class="container">
        <div class="row">

            <div class="col-md-8 col-sm-8 ">
                <?php echo $__env->make('partials._main_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="m-t-20"></div>
                <div class="row articles-box">
                    <?php if(count($data['news'])): ?>
                     
                    <?php if(count($data['videos'])): ?>
                    <div class="col-md-8 col-sm-6">
                    <?php else: ?>    
                    <div class="col-md-12 col-sm-6">
                    <?php endif; ?> 
                        <div class="careerfy-typo-wrap categ-title">
                            <h3><span>Latest News</span></h3>
                        </div>
                        <div class="articles-only br-nn">

                            <?php $__currentLoopData = $data['news']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="article-item">
                                <div class="article-tags">
                                    <?php $__currentLoopData = $post->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span><a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>"><?php echo e($topic->title ?? ''); ?></a></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="clearfix"></div>
                                <h2><a href="<?php echo e('/'.$post->post_type.'/'.$post->slug); ?>"><?php echo e(implode(' ', array_slice(explode(' ', $post->title), 0, 30))); ?><?php if( str_word_count($post->title) > 30 ): ?>...<?php endif; ?></a></h2>
                                <h4>
                                    <span> <?php echo e($post->author ?? ''); ?> </span>
    
                                    <text><?php if($post->author): ?> &nbsp;/&nbsp; <?php endif; ?><span> <?php echo e($post->created_at->format('M d, Y') ?? ''); ?> </span></text>
    
                                </h4>
                                <div class="article-img-text">
                                    <?php $__currentLoopData = $post->postmeta->where('meta_key', '_featured_image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img src="<?php echo e(asset('uploads/'.$value->meta_value )); ?>" alt="<?php echo e($value->meta_value); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!count($post->postmeta->where('meta_key', '_featured_image')) ): ?>
                                    <img src="<?php echo e(asset('uploads/d-post.jpeg')); ?>" alt="oncologyme">
                                    <?php endif; ?>
                                    <p><?php echo e(implode(' ', array_slice(explode(' ', $post->excerpt), 0, 20))); ?><?php if( str_word_count($post->excerpt) > 20 ): ?>...<?php endif; ?></p>
                                </div>
                            </div>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if(count($data['videos'])): ?>
                    <?php if(count($data['news'])): ?>
                    <div class="col-md-4 col-sm-6">
                    <?php else: ?>  
                    <div class="col-md-12 col-sm-6">
                    <?php endif; ?> 
                        <div class="careerfy-typo-wrap categ-title">
                            <h3 class="text-right"><span>Latest Videos</span></h3>
                        </div>
                        <div class="videos-only brdr-bf br-nn">
                            <?php $__currentLoopData = $data['videos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <div class="article-item">
                                <div class="article-tags">
                                    <div class="video-thumbnail pos-rltv home-vid">
                                        <a href="<?php echo e($post->post_type.'/'.$post->slug); ?>">
                                            <?php $__currentLoopData = $post->postmeta->where('meta_key', '_featured_image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img src="<?php echo e(asset('uploads/'.$value->meta_value )); ?>" alt="<?php echo e($value->meta_value); ?>">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!count($post->postmeta->where('meta_key', '_featured_image')) ): ?>
                                            <img src="<?php echo e(asset('uploads/d-post.jpeg')); ?>" alt="oncologyme">
                                            <?php endif; ?>
                                            <img class="pos-abslt" src="<?php echo e(asset('front-assets/img/play.png')); ?>">
                                        </a>
                                    </div>
                                    <?php $__currentLoopData = $post->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span><a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>"><?php echo e($topic->title ?? ''); ?></a></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                                <div class="clearfix"></div>
                                <h2><a href="<?php echo e($post->post_type.'/'.$post->slug); ?>"><?php echo e(implode(' ', array_slice(explode(' ', $post->title), 0, 10))); ?><?php if( str_word_count($post->title) > 10 ): ?>...<?php endif; ?></a></h2>
                                <h4>
                                    <span> <?php echo e($post->author ?? ''); ?> </span>
    
                                    <text><?php if($post->author): ?> &nbsp;/&nbsp; <?php endif; ?><span> <?php echo e($post->created_at->format('M d, Y') ?? ''); ?> </span></text>
    
                                </h4>
                            </div>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php echo $__env->make('partials._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<!-- Main Section -->

<?php if(count( $data['main_study_articles'] ) ): ?>
<!-- Main Section -->
<div class="careerfy-main-section careerfy-parallex-full articles-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12 careerfy-typo-wrap">
                <h3><span>Latest Studying slides</span></h3>
            </div>
            <div class="articles-box ">
                <div class="articles-only">
                    <div class="col-md-4 col-sm-4 col-xs-12 articles-only">
                        <div class="article-item-main">
                            <?php $__currentLoopData = $data['main_study_articles'][0]->postmeta->where('meta_key', '_featured_image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>"><img src="<?php echo e(asset('uploads/'.$value->meta_value )); ?>" alt="<?php echo e($value->meta_value); ?>"></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!count($data['main_study_articles'][0]->postmeta->where('meta_key', '_featured_image')) ): ?>
                            <a href="<?php echo e($data['main_study_articles'][0]->post_type.'/'.$data['main_study_articles'][0]->slug); ?>"><img src="<?php echo e(asset('uploads/d-post.jpeg')); ?>" alt="oncologyme"></a>
                            <?php endif; ?>
                            <div class="article-tags">
                                <?php $__currentLoopData = $data['main_study_articles'][0]->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>"><?php echo e($topic->title ?? ''); ?></a></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="clearfix"></div>
                            <h2><a href="<?php echo e($data['main_study_articles'][0]->post_type.'/'.$data['main_study_articles'][0]->slug); ?>"><?php echo e(implode(' ', array_slice(explode(' ', $data['main_study_articles'][0]->title ?? ''), 0, 10))); ?><?php if( str_word_count($data['main_podcast'][0]->title ?? '') > 10 ): ?>...<?php endif; ?></a></h2>
                            <div class="article-img-text">
                                <p><?php echo e($data['main_study_articles'][0]->excerpt); ?></p>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-md-8 col-sm-4 col-xs-12 articles-only">
                        <?php $__currentLoopData = $data['study_articles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="article-item col-md-6 col-sm-6 col-xs-12 ">
                            <h2><a href="<?php echo e($post->post_type.'/'.$post->slug ?? ''); ?>"><?php echo e(implode(' ', array_slice(explode(' ', $post->title ?? ''), 0, 10))); ?><?php if( str_word_count($post->title ?? '') > 10 ): ?>...<?php endif; ?></a></h2>
                            <div class="article-tags">
                                <?php $__currentLoopData = $post->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>"><?php echo e($topic->title ?? ''); ?></a></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="clearfix"></div>

                            <div class="article-img-text">
                                <?php $__currentLoopData = $post->postmeta->where('meta_key', '_featured_image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>"><img src="<?php echo e(asset('uploads/'.$value->meta_value )); ?>" alt="<?php echo e($value->meta_value); ?>"></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!count($post->postmeta->where('meta_key', '_featured_image')) ): ?>
                                    <a href="<?php echo e($post->post_type.'/'.$data['main_study_articles'][0]->slug); ?>"><img src="<?php echo e(asset('uploads/d-post.jpeg')); ?>" alt="oncologyme"></a>
                                <?php endif; ?>
                                <p><?php echo e(implode(' ', array_slice(explode(' ', $post->excerpt ?? ''), 0, 10))); ?><?php if( str_word_count($post->excerpt ?? '') > 10 ): ?>...<?php endif; ?></p>
                                
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Main Section -->
<?php endif; ?>

<?php if(count( $data['main_podcast'] ) ): ?>
<!-- Main Section -->
<div class="careerfy-main-section careerfy-parallex-full articles-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12 careerfy-typo-wrap">
                <h3><span>Latest Podcasts</span></h3>
            </div>
            <div class="articles-box ">
                <div class="articles-only">
                    <div class="col-md-4 col-sm-4 col-xs-12 articles-only">
                        <div class="article-item-main">
                            <?php $__currentLoopData = $data['main_podcast'][0]->postmeta->where('meta_key', '_featured_image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>"><img src="<?php echo e(asset('uploads/'.$value->meta_value )); ?>" alt="<?php echo e($value->meta_value); ?>"></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!count($data['main_podcast'][0]->postmeta->where('meta_key', '_featured_image')) ): ?>
                            <a href="<?php echo e($data['main_podcast'][0]->post_type.'/'.$data['main_podcast'][0]->slug); ?>"><img src="<?php echo e(asset('uploads/d-post.jpeg')); ?>" alt="oncologyme"></a>
                            <?php endif; ?>
                            <div class="article-tags">
                                <?php $__currentLoopData = $data['main_podcast'][0]->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>"><?php echo e($topic->title ?? ''); ?></a></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="clearfix"></div>
                            <h2><a href="<?php echo e($data['main_podcast'][0]->post_type.'/'.$data['main_podcast'][0]->slug); ?>"><?php echo e(implode(' ', array_slice(explode(' ', $data['main_podcast'][0]->title ?? ''), 0, 10))); ?><?php if( str_word_count($data['main_podcast'][0]->title ?? '') > 10 ): ?>...<?php endif; ?></a></h2>
                            <div class="article-img-text">
                                <p><?php echo e($data['main_podcast'][0]->excerpt); ?></p>
                                <div class="podcast-link">
                                    <a href="<?php echo e($data['main_podcast'][0]->post_type.'/'.$data['main_podcast'][0]->slug); ?>">Listen now <i class="fa fa-headphones"></i></a>
                                </div>
                            </div>
                            
                        </div>

                    </div>
                    <div class="col-md-8 col-sm-4 col-xs-12 articles-only">
                        <?php $__currentLoopData = $data['podcasts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="article-item col-md-6 col-sm-6 col-xs-12 ">
                            <h2><a href="<?php echo e($post->post_type.'/'.$post->slug ?? ''); ?>"><?php echo e(implode(' ', array_slice(explode(' ', $post->title ?? ''), 0, 10))); ?><?php if( str_word_count($post->title ?? '') > 10 ): ?>...<?php endif; ?></a></h2>
                            <div class="article-tags">
                                <?php $__currentLoopData = $post->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>"><?php echo e($topic->title ?? ''); ?></a></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="clearfix"></div>

                            <div class="article-img-text">
                                <?php $__currentLoopData = $post->postmeta->where('meta_key', '_featured_image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($post->post_type.'/'.$post->slug); ?>"><img src="<?php echo e(asset('uploads/'.$value->meta_value )); ?>" alt="<?php echo e($value->meta_value); ?>"></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!count($post->postmeta->where('meta_key', '_featured_image')) ): ?>
                                    <a href="<?php echo e($post->post_type.'/'.$post->slug); ?>"><img src="<?php echo e(asset('uploads/d-post.jpeg')); ?>" alt="oncologyme"></a>
                                <?php endif; ?>

                                <p><?php echo e(implode(' ', array_slice(explode(' ', $post->excerpt ?? ''), 0, 10))); ?><?php if( str_word_count($post->excerpt ?? '') > 10 ): ?>...<?php endif; ?></p>
                                
                            </div>
                        </div>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>
<!-- Main Section -->
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/frontend/home.blade.php ENDPATH**/ ?>