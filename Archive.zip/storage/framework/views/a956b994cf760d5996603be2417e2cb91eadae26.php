<?php $__env->startSection('meta'); ?>

<title> <?php echo e($data['page']->page_title); ?> - <?php echo e($general_info[0]->tagline); ?>  </title>
<meta name="title" content="<?php echo e($data['page']->meta_title ?? ''); ?>">
<meta name="description" content="<?php echo e($data['page']->meta_desc ?? ''); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<!-- Main Section -->
<div class="careerfy-main-section careerfy-about-text-full">
    <div class="container">
        <div class="row">

            <?php if(count($highlights) || count($latest_news) || count($top_banners) || count($bottom_banners)): ?>
            <div class="col-md-8 careerfy-typo-wrap">
            <?php else: ?>
            <div class="col-md-12 careerfy-typo-wrap">
            <?php endif; ?>
                <div class="careerfy-about-text">
                    <div class="careerfy-contact-info-sec">
                        <h2>Contact Information</h2>
                        <p><?php echo e($general_info[0]->about); ?></p>
                        <p><?php echo e($general_info[0]->short_description); ?>.</p>
                        <ul class="careerfy-contact-info-list">
                            <li><i class="careerfy-icon careerfy-placeholder"></i> <a href="https://maps.app.goo.gl/xSs4KQ9drppdsJgs7" target="_blank"> 37, Omarat Madinat Al Fath, Al Hadiqah Ad Dawleyah, Embassies District, Nasr City, Cairo Governorate, Egypt <span style="font-size: 12px; text-decoration: underline; float: none;"> Veiw on map </span></a>                                            </li>
                            <li><i class="careerfy-icon careerfy-mail"></i> <a href="mailto:<?php echo e($general_info[0]->email); ?>">Email: <?php echo e($general_info[0]->email); ?></a></li>
                            <li><i class="careerfy-icon careerfy-technology"></i>  <a href="tel:<?php echo e($general_info[0]->phone); ?>"> Call: <?php echo e($general_info[0]->phone); ?></a></li>
                        </ul>
                        <div class="careerfy-contact-media">
                            <a href="<?php echo e($general_info[0]->fb); ?>" class="careerfy-icon careerfy-facebook-logo" target="_blank"></a>
                            <a href="<?php echo e($general_info[0]->youtube); ?>" class="careerfy-bgcolorhover cs-yout" target="_blank"><i class="fa fa-youtube-play"></i></a>
                            <a href="<?php echo e($general_info[0]->linkedin); ?>" class="careerfy-icon careerfy-linkedin-button" target="_blank"></a>
                        </div>
                    </div>
                    <div class="careerfy-contact-form">
                        <h2>We want to hear from you!</h2>
                        <?php echo Form::open(['route' => ['contact.data'], 'method' => 'post']); ?>

                            <ul>
                                <li>
                                    <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Enter Your Name', 'required' => 'required']); ?>

                                    <i class="careerfy-icon careerfy-user"></i>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback cs-danger" role="alert">
                                        <?php echo e($message); ?>

                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </li>
                                <li>
                                    <?php echo Form::text('subject', null, ['class' => 'form-control', 'placeholder' => 'Subject', 'required' => 'required']); ?>

                                    <i class="careerfy-icon careerfy-user"></i>
                                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback cs-danger" role="alert">
                                        <?php echo e($message); ?>

                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </li>
                                <li>
                                    <?php echo Form::text('email', null, ['class' => 'form-control' , 'placeholder' => 'Enter Your Email Address', 'required' => 'required']); ?>

                                    <i class="careerfy-icon careerfy-mail"></i>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback cs-danger" role="alert">
                                        <?php echo e($message); ?>

                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </li>
                                <li>
                                    <?php echo Form::text('phone', null, ['class' => 'form-control' , 'placeholder' => 'Enter Your Phone Number', 'required' => 'required']); ?>

                                    <i class="careerfy-icon careerfy-technology"></i>
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback cs-danger" role="alert">
                                        <?php echo e($message); ?>

                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </li>
                                <li class="careerfy-contact-form-full">
                                    <?php echo Form::textarea('message', null, [
                                        'class'      => 'form-control',
                                        'rows'       => 3, 
                                        'name'       => 'message',
                                        'id'         => 'message',
                                        'onkeypress' => "return nameFunction(event);",
                                        'placeholder'=> "Write your message ...",
                                        'required' => 'required'
                                    ]); ?>

                                     <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <span class="invalid-feedback cs-danger" role="alert">
                                         <?php echo e($message); ?>

                                     </span>
                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </li>
                                <li>  <?php echo Form::submit('submit', ['class' => 'btn']); ?></li>
                            </ul>
                            <div class="clearfix"></div>
                        <?php echo Form::close(); ?>

                        <div class="cs-msgs">
                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- sidebar -->
            <?php echo $__env->make('partials._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        </div>
    </div>
</div>
<!-- Main Section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/frontend/contact-us.blade.php ENDPATH**/ ?>