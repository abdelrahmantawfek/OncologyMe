<div class="container ">
    <div class="row">
        <aside class="col-md-2 col-xs-5">
            <a href="/" class="careerfy-logo"><img src="<?php echo e(asset('front-assets/img/logo.png')); ?>" alt=""></a>
        </aside>
        <aside class="col-md-8 col-xs-2 pos-unset no-pd">
            <nav class="careerfy-navigation">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#careerfy-navbar-collapse-1" aria-expanded="false">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="careerfy-navbar-collapse-1">
                    <ul class="navbar-nav">
                        <li class="<?php echo e(Request::is('/') ? 'active' : ''); ?>"><a href="/"><?php echo e($home_title->page_title ?? ''); ?></a></li>
                        <li class="<?php echo e(Request::is('about-oncology-me') ? 'active' : ''); ?> <?php echo e(Request::is('editorial') ? 'active' : ''); ?> <?php echo e(Request::is('rights') ? 'active' : ''); ?> <?php echo e(Request::is('contact-us') ? 'active' : ''); ?>"><a href="javascript:void(0)">About Us <i class="fa fa-angle-down"></i></a>
                            <ul class="sub-menu cs-sub-menu">
                                <li><a href="<?php echo e(route('about')); ?>" class="<?php echo e(Request::is('about-oncology-me') ? 'active' : ''); ?>"><?php echo e($about_title->page_title ?? ''); ?></a></li>
                                <li><a href="<?php echo e(route('editorial')); ?>" class="<?php echo e(Request::is('editorial') ? 'active' : ''); ?>"><?php echo e($editorial_title->page_title ?? ''); ?></a></li>
                                <li><a href="<?php echo e(route('rights')); ?>" class="<?php echo e(Request::is('rights') ? 'active' : ''); ?>"><?php echo e($rights_title->page_title ?? ''); ?></a></li>
                                <li><a href="<?php echo e(route('contact')); ?>" class="<?php echo e(Request::is('contact-us') ? 'active' : ''); ?>"><?php echo e($contact_title->page_title ?? ''); ?></a></li>
                            </ul>
                        </li>
                        <?php if(count($topics)): ?>
                        <li class="<?php echo e(Request::is('topics') ? 'active' : ''); ?> <?php echo e(Request::is('topics/*') ? 'active' : ''); ?> "><a href="javascript:void(0)"><?php echo e($topics_title->page_title ?? ''); ?> <i class="fa fa-angle-down"></i></a>
                            <ul class="sub-menu cs-sub-menu">
                                <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>" class="<?php echo e(Request::is('topics/' .$topic->slug) ? 'active' : ''); ?>"><?php echo e($topic->title ?? ''); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('allTopics')); ?>" class="<?php echo e(Request::is('topics') ? 'active' : ''); ?>">View All</a></li>
                            </ul>
                        </li>
                        
                        <?php elseif(count($allst_topics)): ?>
                        <li class="pos-unset <?php echo e(Request::is('topics') ? 'active' : ''); ?> <?php echo e(Request::is('topics/*') ? 'active' : ''); ?>"><a href="<?php echo e(route('allTopics')); ?>"><?php echo e($topics_title->page_title ?? ''); ?></a></li>
                        <?php endif; ?>
                        <?php if(count($news_categories)): ?>
                        <li class="pos-unset <?php echo e(Request::is('all-news') ? 'active' : ''); ?> <?php echo e(Request::is('news/*') ? 'active' : ''); ?> ">
                            <a href="javascript:void(0)"><?php echo e($news_title->page_title ?? ''); ?> <i class="fa fa-angle-down"></i></a>
                            <ul class="sub-menu cs-sub-menu">
                                <?php $__currentLoopData = $news_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('showCategory', [$category->post_type, $category->slug])); ?>" class="<?php echo e(Request::is('news/categories/' .$category->slug) ? 'active' : ''); ?>"><?php echo e($category->title ?? ''); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="/all-news" class="<?php echo e(Request::is('all-news') ? 'active' : ''); ?>">View All</a></li>
                            </ul>
                        </li>
                        <?php elseif(count($allst_news)): ?>
                        <li class="pos-unset <?php echo e(Request::is('all-news') ? 'active' : ''); ?>"><a href="/all-news"><?php echo e($news_title->page_title ?? ''); ?></a></li>
                        <?php endif; ?>
                        <?php if(count($videos_categories)): ?>
                        <li class="pos-unset <?php echo e(Request::is('all-videos') ? 'active' : ''); ?> <?php echo e(Request::is('videos/*') ? 'active' : ''); ?>"><a href="javascript:void(0)"><?php echo e($watch_title->page_title ?? ''); ?> <i class="fa fa-angle-down"></i></a>
                            <ul class="sub-menu dsply-dsk">
                                <div class="owl-carousel vid-carousel cs-nav carousel slide">
                                    <?php $__currentLoopData = $videos_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="">
                                        <div class="thumbnail">
                                            <a href="<?php echo e(route('showCategory', [$category->post_type, $category->slug])); ?>"> <img src="<?php echo e(asset('uploads/'.$category->featured_image)); ?>" alt="<?php echo e($category->featured_image); ?>"></a>
                                            <div class="caption">
                                                <h3><a href="<?php echo e(route('showCategory', [$category->post_type, $category->slug])); ?>"><?php echo e($category->title ?? ''); ?></a></h3>
                                                <p><a href="<?php echo e(route('showCategory', [$category->post_type, $category->slug])); ?>">Read More</a></p>
                                            </div>
                                        </div>
                                    </div>  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </div>
                                  <div class="cs-readmore"><a href="/all-videos">View All</a></div>
                            </ul>

                            <ul class="sub-menu cs-sub-menu dsply-mob">
                                <?php $__currentLoopData = $videos_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('showCategory', [$category->post_type, $category->slug])); ?>"><?php echo e($category->title ?? ''); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="/all-videos">View All</a></li>
                            </ul>
                        </li>
                        <?php elseif(count($allst_videos)): ?>
                        <li class="pos-unset <?php echo e(Request::is('all-videos') ? 'active' : ''); ?>"><a href="/all-videos"><?php echo e($watch_title->page_title ?? ''); ?></a></li>
                        <?php endif; ?>
                        <?php if(count($articles_categories)): ?>
                        <li class="pos-unset <?php echo e(Request::is('all-articles') ? 'active' : ''); ?> <?php echo e(Request::is('articles/*') ? 'active' : ''); ?>"><a href="javascript:void(0)"><?php echo e($articles_title->page_title ?? ''); ?> <i class="fa fa-angle-down"></i></a>
                            <ul class="sub-menu dsply-dsk">
                                <div class="owl-carousel art-carousel cs-nav carousel slide">
                                    <?php $__currentLoopData = $articles_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="">
                                        <div class="thumbnail">
                                            <a href="<?php echo e(route('showCategory', [$category->post_type, $category->slug])); ?>"> <img src="<?php echo e(asset('uploads/'.$category->featured_image)); ?>" alt="<?php echo e($category->featured_image); ?>"></a>
                                            <div class="caption">
                                                <h3><a href="<?php echo e(route('showCategory', [$category->post_type, $category->slug])); ?>"><?php echo e($category->title ?? ''); ?></a></h3>

                                                <p><a href="<?php echo e(route('showCategory', [$category->post_type, $category->slug])); ?>">Read More</a></p>
                                            </div>
                                        </div>
                                    </div>  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </div>
                                  <div class="cs-readmore"><a href="/all-articles">View All</a></div>
                            </ul>

                            <ul class="sub-menu cs-sub-menu dsply-mob">
                                <?php $__currentLoopData = $articles_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('showCategory', [$category->post_type, $category->slug])); ?>"><?php echo e($category->title ?? ''); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="/all-articles">View All</a></li>
                            </ul>
                        </li>
                        <?php elseif(count($allst_articles)): ?>
                        <li class="pos-unset <?php echo e(Request::is('all-articles') ? 'active' : ''); ?>"><a href="/all-articles"><?php echo e($articles_title->page_title ?? ''); ?></a></li>
                        <?php endif; ?>
                        <?php if(count($allst_podcasts)): ?>
                        <li class="pos-unset <?php echo e(Request::is('all-podcasts') ? 'active' : ''); ?>"><a href="/all-podcasts"><?php echo e($podcasts_title->page_title ?? ''); ?></a></li>
                        <?php endif; ?>

                    </ul>
                </div>
            </nav>
        </aside>
        <aside class="col-md-2 col-xs-5 no-pd">
            <div class="careerfy-right">
                <?php if(Route::has('login')): ?>
                <ul class="careerfy-user-section cs-acc-menu dsply-dsk">
                    <?php if(auth()->guard()->check()): ?>
                    <li class="btn1"><a class="careerfy-color careerfy-open-signin-tab" href="<?php echo e(route('user.profile')); ?>"><i class="fa fa-user"></i></a></li>
                    <li class="logout-btn"><a class="careerfy-color careerfy-open-signin-tab" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">Log out</a></li>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                    <?php else: ?>
                    <li class="btn1"><a class="careerfy-color careerfy-open-signin-tab" href="<?php echo e(route('login')); ?>">Log in</a></li>
                    <?php if(Route::has('register')): ?>
                    <li class="btn2"><a class="careerfy-color careerfy-open-signup-tab" href="<?php echo e(route('register')); ?>">Register Now </a></li>
                    <?php endif; ?>
                    <?php endif; ?>
                </ul>
                <ul class="careerfy-user-section cs-acc-menu dsply-mob">
                    <?php if(auth()->guard()->check()): ?>
                    <li class="btn1"><a class="careerfy-color careerfy-open-signin-tab" href="<?php echo e(route('user.profile')); ?>"><i class="fa fa-user"></i></a></li>
                    <li class="logout-btn"><a class="careerfy-color careerfy-open-signin-tab" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"><i class="fa fa-sign-out"></i></a></li>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                    <?php else: ?>
                    <li class="btn1"><a class="careerfy-color careerfy-open-signin-tab" href="<?php echo e(route('login')); ?>"><i class="fa fa-sign-in"></i></a></li>
                    <?php if(Route::has('register')): ?>
                    <li class="btn2"><a class="careerfy-color careerfy-open-signup-tab" href="<?php echo e(route('register')); ?>"><i class="fa fa-user-o"></i></a></a></li>
                    <?php endif; ?>
                    <?php endif; ?>
                </ul>

                <?php endif; ?>

                <div class="event__search__floater">
                    <div class="search__anchor">
                        <form id="event-search-form" method="GET" action="<?php echo e(route('searchPosts')); ?>">
                            <input type="text" class="search__bar" placeholder="Search" name="search" required>
                            <input class="search__submit" type="submit">
                            <div class="search__toggler"></div>
                        </form>

                    </div>
                </div>

            </div>
        </aside>
    </div>
</div>

<?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/partials/_header.blade.php ENDPATH**/ ?>