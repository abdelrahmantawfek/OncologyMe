<?php $__env->startSection('meta'); ?>

<title> <?php echo e($data['topic']->title ?? ''); ?> - <?php echo e($general_info[0]->tagline); ?> </title>
<meta name="title" content="<?php echo e($data['topic']->meta_title ?? ''); ?>">
<meta name="description" content="<?php echo e($data['topic']->meta_desc ?? ''); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

            <!-- Main Section -->
            <div class="careerfy-main-section careerfy-counter-full topics-section">
                <div class="container">
                    <div class="row">
                        <?php if(count($highlights) || count($latest_news) || count($top_banners) || count($bottom_banners)): ?>
                        <div class="col-md-8">
                        <?php else: ?>
                        <div class="col-md-12">
                        <?php endif; ?>
                        

                            <div class="m-t-20"></div>
                            <div class="careerfy-typo-wrap categ-title pos-rltv">
                                <h3><span><?php echo e($data['topic']->title); ?></span></h3>
                                <?php if(count($data['other-topics'])): ?>
                                <?php echo Form::open(['route' => ['searchTopic', $data['topic']->slug ], 'method' => 'GET', 'class' => 'all-category', 'id' => 'select_topic']); ?>

                                    <div class="form-group">
                                        <?php echo Form::select('topics', $data['other-topics'], null, ['class' => 'form-control', 'id' => 'category', 'placeholder' => 'Select a topic'] ); ?>

                                    </div>
                                <?php echo Form::close(); ?>

                                <?php endif; ?>
                            </div>
                            <?php echo $__env->make('partials._posts_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <div class="row articles-box">
                                <div class=" <?php if( !count($data['videos']->where('meta_key', '_featured_image')) ): ?>col-md-8 <?php else: ?> col-md-12 <?php endif; ?> col-sm-6">
                                    <div class="articles-only br-nn">
                                        <?php $__currentLoopData = $data['news']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="article-item">
                                            <div class="article-tags">
                                                <?php $__currentLoopData = $post->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span><a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>"><?php echo e($topic->title ?? ''); ?></a></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <div class="clearfix"></div>
                                            <h2><a href="<?php echo e('/'.$post->post_type.'/'.$post->slug); ?>"><?php echo e(implode(' ', array_slice(explode(' ', $post->title), 0, 30))); ?><?php if( str_word_count($post->title) > 30 ): ?>...<?php endif; ?></a></h2>
                                            <h4>
                                                
                
                                                
                
                                            </h4>
                                            <div class="article-img-text">
                                                <?php $__currentLoopData = $post->postmeta->where('meta_key', '_featured_image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <img src="<?php echo e(asset('uploads/'.$value->meta_value )); ?>" alt="<?php echo e($value->meta_value); ?>">
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <p><?php echo e(implode(' ', array_slice(explode(' ', $post->excerpt), 0, 20))); ?><?php if( str_word_count($post->excerpt) > 20 ): ?>...<?php endif; ?></p>
                                            </div>
                                        </div>    
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                </div>
                                <div class=" <?php if(!count($data['news'])): ?> col-md-12 <?php else: ?> col-md-4 <?php endif; ?> col-sm-6 cs-vid-only">

                                    <div class="videos-only brdr-bf br-nn">
                                        <?php $__currentLoopData = $data['videos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(count($post->postmeta->where('meta_key', '_featured_image')) ): ?>
                                        <div class="article-item <?php if(!count($data['news'])): ?> col-md-4 <?php else: ?> col-md-12 <?php endif; ?> p-0">
                                            <div class="article-tags">
                                                <div class="video-thumbnail pos-rltv">
                                                    <a href="<?php echo e('/'.$post->post_type.'/'.$post->slug); ?>">
                                                        <?php $__currentLoopData = $post->postmeta->where('meta_key', '_featured_image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <img src="<?php echo e(asset('uploads/'.$value->meta_value )); ?>" alt="<?php echo e($value->meta_value); ?>">
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                        <img class="pos-abslt" src="<?php echo e(asset('front-assets/img/play.png')); ?>">
                                                    </a>
                                                </div>
                                                <?php $__currentLoopData = $post->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span><a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>"><?php echo e($topic->title ?? ''); ?></a></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </div>
                                            <div class="clearfix"></div>
                                            <h2><a href="<?php echo e('/'.$post->post_type.'/'.$post->slug); ?>"><?php echo e(implode(' ', array_slice(explode(' ', $post->title), 0, 10))); ?><?php if( str_word_count($post->title) > 10 ): ?>...<?php endif; ?></a></h2>
                                            <h4>
                                                
                
                                                
                
                                            </h4>
                                        </div>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                </div>

                            </div>
                        </div>
                        <!-- sidebar -->
                        <?php echo $__env->make('partials._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>
                </div>
            </div>
            <!-- Main Section -->






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/frontend/single-topic.blade.php ENDPATH**/ ?>