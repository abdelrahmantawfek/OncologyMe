<?php $__env->startSection('meta'); ?>

   <title> Sign Up  - <?php echo e($general_info[0]->tagline); ?> </title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Section -->
<div class="careerfy-main-section careerfy-about-text-full">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 careerfy-typo-wrap">
                <div class="jobsearch-login-box" id="exTab1">
                    <div class="div-signup">
                        <div class="careerfy-services-classic">
                            <span><i class="careerfy-icon careerfy-user-1"></i></span>
                        </div>
                        <h3>Create New Account</h3>

                    </div>
                    <div class="cs-msgs form-group">
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                

                    <form method="POST" action="<?php echo e(route('postSignup')); ?>" class="row">
                        <?php echo csrf_field(); ?>
                        <div class="form-group col-md-6">
                            <input id="first_name" type="text" class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="first_name" value="<?php echo e(old('first_name')); ?>" required autocomplete="first_name" placeholder="First Name">
                            <i class="careerfy-icon careerfy-user"></i>
                            
                        </div>

                        <div class="form-group col-md-6">
                            <input id="last_name" type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="last_name" value="<?php echo e(old('last_name')); ?>" required autocomplete="last_name" placeholder="Last Name">
                            <i class="careerfy-icon careerfy-user"></i>
                            
                        </div>

                        <div class="form-group col-md-6">
                            <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Email"> 
                            <i class="careerfy-icon careerfy-mail"></i>
                            
                        </div>

                        <div class="form-group col-md-6">
                            <input id="phone" type="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone" value="<?php echo e(old('phone')); ?>" required autocomplete="phone" placeholder="Phone">
                            <i class="careerfy-icon careerfy-technology"></i>
                            
                        </div>

                        <div class="form-group col-md-6">
                            <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="password" placeholder="Password">
                            <i class="careerfy-icon careerfy-multimedia"></i>
                            
                        </div>

                        <div class="form-group col-md-6">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" placeholder="Confirm Password">
                            <i class="careerfy-icon careerfy-multimedia"></i>
                        </div>

                        <div class="form-group col-md-6">
                            <?php echo Form::select('country', $countries, null, ['class' => 'form-control', 'placeholder' => 'Country', 'required' => 'required', 'id' => 'country' ]); ?>

                            
                        </div>

                        <div class="form-group col-md-6 cs-gov">
                            <?php echo Form::select('governorate', $governorates, null, ['class' => 'form-control', 'placeholder' => 'Governorate']); ?>

                            
                        </div>

                        <div class="form-group col-md-6 other-gov" style="display: none;">
                            <input name='other_governorate' class="form-control" type="text" placeholder="Governorate">
                            <i class="careerfy-icon careerfy-edit"></i>
                            
                        </div>

                        <div class="form-group col-md-6">
                            <div class="combo-select-dropdown">
                                <ul class="select-list-group" id="ComboSelect3">
                                    <li class="select-lg-dropdown">
                                        <input type="text" class="select-list-group-search" name="affiliation" placeholder="Affiliation " required />
                                        <ul class="select-list-group-list" data-toggle="false">
                                            <?php $__currentLoopData = $affiliations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="select-list-group-list-item" data-display="true" data-highlight="false"><?php echo e($item); ?></li> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        </li>
                                </ul>
                                
                            </div>
                        </div>

                        <div class="form-group col-md-6">
                            <div class="combo-select-dropdown">
                                <ul class="select-list-group" id="ComboSelect">
                                    <li class="select-lg-dropdown">
                                        <input type="text" name="speciality" class="select-list-group-search" placeholder="Speciality" required />
                                        <ul class="select-list-group-list" data-toggle="false">
                                            <?php $__currentLoopData = $specialites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="select-list-group-list-item" data-display="true" data-highlight="false"><?php echo e($item); ?></li> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        </li>
                                </ul>
                                
                            </div>
                        </div>
              

                        <div class="m-b-15 m-t-15 col-md-12">
                            <div class="terms-priv-chek-con">
                                <p>
                                    <?php echo Form::checkbox('accept_newsletter_emails', true, null, ['id' => 'newsletter']); ?> <label for="newsletter"> I consent to receiving Newsletters emails</label>
                                </p>
                            </div>
                        </div>
                        <div class="m-b-15 m-t-15 col-md-12">
                            <button type="submit" class="btn btn-primary pull-left">Sign Up</button>
                            <p class="pull-right p-t-10">Already have an account?
                                <a href="<?php echo e(route('login')); ?>" class=" careerfy-open-signin-tab ">Sign in</a></p>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Main Section -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/auth/register.blade.php ENDPATH**/ ?>