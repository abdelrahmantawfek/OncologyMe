<?php if(count($highlights) || count($latest_news) || count($top_banners) || count($bottom_banners)): ?>
<div class="col-md-4 col-sm-4">
    <div class="banr-box">
    <div class="owl-carousel top-banner banner-nav">
        <?php $__currentLoopData = $top_banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div> 
            <a href="<?php echo e($item->url); ?>" target="_blank">
                <img class="d-block w-100" src="<?php echo e(asset('uploads/'.$item->desktop_image)); ?>">
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
    <div class="topics-box-clmn">
        <!-- TIN Calendar -->
        <div class="topics-box">
        <?php echo $__env->make('partials._highlights-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="topics-box">
        <?php echo $__env->make('partials._latest-articles-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="banr-box">
    <div class="owl-carousel bottom-banner banner-nav">
        <?php $__currentLoopData = $bottom_banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div> 
            <a href="<?php echo e($item->url); ?>" target="_blank">
                <img class="d-block w-100" src="<?php echo e(asset('uploads/'.$item->desktop_image)); ?>">
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
</div>
<?php endif; ?><?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/partials/_sidebar.blade.php ENDPATH**/ ?>