<?php $__env->startSection('meta'); ?>

<title> <?php echo e($data['page']->page_title); ?> - <?php echo e($general_info[0]->tagline); ?>  </title>
<meta name="title" content="<?php echo e($data['page']->meta_title ?? ''); ?>">
<meta name="description" content="<?php echo e($data['page']->meta_desc ?? ''); ?>">
<meta name="keywords" content="<?php echo e($data['page']->meta_keywords ?? ''); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!-- Main Section -->
<?php $__currentLoopData = $data['page']->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="careerfy-main-section careerfy-about-text-full">
    <div class="container">
        <div class="row">

            <?php if($section->layout == 1): ?>
            <div class="col-md-6 careerfy-typo-wrap">
                <div class="careerfy-about-thumb"><img src="<?php echo e(asset('uploads/'.$section->img?? '')); ?>" alt="oncologyme"></div>
            </div>
            <?php endif; ?>

            <div class="col-md-6 careerfy-typo-wrap">
                <div class="careerfy-about-text">
                    <h2><?php echo e($section->title ?? ''); ?></h2>
                    <span class="careerfy-about-sub"><?php echo e($section->subtitle?? ''); ?></span>
                    <p><?php echo $section->content?? ''; ?></p>
            </div>
            </div>
            <?php if($section->layout == 0): ?>
            <div class="col-md-6 careerfy-typo-wrap">
                <div class="careerfy-about-thumb"><img src="<?php echo e(asset('uploads/'.$section->img?? '')); ?>" alt="oncologyme"></div>
            </div>
            <?php endif; ?>


        </div>
    </div>
</div>

<!-- Main Section -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/frontend/editorial.blade.php ENDPATH**/ ?>