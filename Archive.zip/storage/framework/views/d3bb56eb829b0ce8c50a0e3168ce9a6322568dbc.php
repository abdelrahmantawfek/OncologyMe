<?php $__env->startSection('meta'); ?>

<title> 404  - <?php echo e($general_info[0]->tagline); ?> </title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <div class="careerfy-errorpage-bg">
            <span class="careerfy-errorpage-transparent"></span>
            <div class="container">
                <div class="careerfy-errorpage">
                    <h2>Ooops! Page Not Found!</h2>
                    <p>Sorry ! We could not Find What You Are Looking For.</p>
                    <a href="/"><span>back To homepage</span></a>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/errors/404.blade.php ENDPATH**/ ?>