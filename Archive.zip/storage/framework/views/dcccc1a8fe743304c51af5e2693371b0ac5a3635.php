<?php if(count($latest_news)): ?>

<div class="topics-box-header">
    <h4>Latest Articles</h4>
</div>
<div class="article-home-sidebar">
    <?php $__currentLoopData = $latest_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h5>
        <a href="<?php echo e('/'.$post->post_type.'/'.$post->slug); ?>" class="mostRead">
        
            <div class="topic-link"> <?php echo e(implode(' ', array_slice(explode(' ', $post->title), 0, 10))); ?><?php if( str_word_count($post->title) > 10 ): ?>...<?php endif; ?></div>
            
        </a>
    </h5>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
    <div class="link-bottom-tio"><a href="/all-articles" class="todayinonc">View More&nbsp;<span class="triangle-link fa fa-angle-right"></span></a></div>
</div>

<?php endif; ?><?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/partials/_latest-articles-sidebar.blade.php ENDPATH**/ ?>