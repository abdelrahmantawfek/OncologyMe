<?php $__env->startSection('meta'); ?>

<title> <?php echo e($data['page']->page_title); ?> - <?php echo e($general_info[0]->tagline); ?>  </title>
<meta name="title" content="<?php echo e($data['page']->meta_title ?? ''); ?>">
<meta name="description" content="<?php echo e($data['page']->meta_desc ?? ''); ?>">
<meta name="keywords" content="<?php echo e($data['page']->meta_keywords ?? ''); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!-- Main Section -->
<div class="careerfy-main-section careerfy-about-text-full">
    <div class="container">
        <div class="row">

            <?php if(count($highlights) || count($latest_news) || count($top_banners) || count($bottom_banners)): ?>
            <div class="col-md-8 careerfy-typo-wrap">
            <?php else: ?>
            <div class="col-md-12 careerfy-typo-wrap">
            <?php endif; ?>
                <div class="careerfy-about-text">
                    <h2><?php echo e($data['page']->sections->first()->title ?? ''); ?></h2>
                    <span class="careerfy-about-sub"><?php echo e($data['page']->sections->first()->subtitle?? ''); ?></span>
                    <p><?php echo $data['page']->sections->first()->content?? ''; ?></p>
                </div>
            </div>
            <!-- sidebar -->
            <?php echo $__env->make('partials._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
</div>
<!-- Main Section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/frontend/rights.blade.php ENDPATH**/ ?>