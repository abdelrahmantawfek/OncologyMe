<?php $__env->startSection('meta'); ?>

<title> <?php echo e($data['page']->page_title); ?> - <?php echo e($general_info[0]->tagline); ?>  </title>
<meta name="title" content="<?php echo e($data['page']->meta_title ?? ''); ?>">
<meta name="description" content="<?php echo e($data['page']->meta_desc ?? ''); ?>">
<meta name="keywords" content="<?php echo e($data['page']->meta_keywords ?? ''); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!-- Main Section -->
<div class="careerfy-main-section careerfy-counter-full topics-section">
    <div class="container">
        <div class="row">

            <?php if(count($highlights) || count($latest_news) || count($top_banners) || count($bottom_banners)): ?>
            <div class="col-md-8">
            <?php else: ?>
            <div class="col-md-12">
            <?php endif; ?>
            
                <?php echo $__env->make('partials._posts_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="m-t-20"></div>
                
                <div class="careerfy-typo-wrap categ-title">

                    <h3><span>All Topics</span></h3>


                </div>

                <?php $__currentLoopData = $data['parent_topics']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php    
                $children = DB::table('topics')->where('parent_id', $topic->id)->orderBy('title')->get();
                ?>
                <?php if(count($children) != 0): ?>
                <div class="topics-list">
                    <div class="topics-list-catg">
                        <h3><?php echo e($topic->title); ?></h3>
                        <ul>
                            <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li><a href="<?php echo e(route('showTopic', $child->slug)); ?>"><?php echo e($child->title); ?></a></li>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <!-- sidebar -->
            <?php echo $__env->make('partials._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
</div>
<!-- Main Section -->




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/frontend/all-topics.blade.php ENDPATH**/ ?>