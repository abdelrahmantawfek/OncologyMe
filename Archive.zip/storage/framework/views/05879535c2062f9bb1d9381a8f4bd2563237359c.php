<div class="banr-box">
    <div class="owl-carousel main-banner banner-nav">
        <?php $__currentLoopData = $news_banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div> 
            <a href="<?php echo e($item->url); ?>" target="_blank">
                <img class="d-block w-100" height="90px" src="<?php echo e(asset('uploads/'.$item->desktop_image)); ?>">
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
</div>



<?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/partials/_posts_banner.blade.php ENDPATH**/ ?>