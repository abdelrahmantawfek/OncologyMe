<?php $__env->startSection('meta'); ?>

   <title> Profile </title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Section -->
<div class="careerfy-main-section careerfy-about-text-full">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 careerfy-typo-wrap">
                <div class="jobsearch-login-box" id="exTab1">
                    <div class="div-signup">
                        <div class="careerfy-services-classic">
                            <span><i class="careerfy-icon careerfy-user-1"></i></span>
                        </div>
                        <h3>Update My Account</h3>

                    </div>
                    <div class="cs-msgs form-group">
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                

                    <?php echo Form::model($user, ['route' => ['user.update'], 'method' => 'POST', 'id' => 'update_profile']); ?>

                        <div class="form-group col-md-6">
                            <?php echo Form::text('first_name', null, ['class' => 'form-control', 'id' => 'first_name', 'placholder' => 'First Name']); ?>

                            <i class="careerfy-icon careerfy-user"></i>
                        </div>
                        

                        <div class="form-group col-md-6">
                            <?php echo Form::text('last_name', null, ['class' => 'form-control', 'id' => 'last_name', 'placholder' => 'Last Name']); ?>

                            <i class="careerfy-icon careerfy-user"></i>
                        </div>

                        <div class="form-group col-md-6">
                            <?php echo Form::text('email', null, ['class' => 'form-control', 'id' => 'email', 'placholder' => 'Email']); ?>

                            <i class="careerfy-icon careerfy-mail"></i>
                        </div>

                        <div class="form-group col-md-6">
                            <?php echo Form::text('phone', null, ['class' => 'form-control', 'id' => 'phone', 'placholder' => 'Phone']); ?>

                            <i class="careerfy-icon careerfy-technology"></i>
                        </div>

                        <div class="form-group col-md-6">
                            <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" autocomplete="password" placeholder="Password">
                            <i class="careerfy-icon careerfy-multimedia"></i>
                        </div>

                        <div class="form-group col-md-6">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" autocomplete="new-password" placeholder="Confirm Password">
                            <i class="careerfy-icon careerfy-multimedia"></i>
                        </div>

                        <div class="form-group col-md-6">
                            <?php echo Form::select('country', $countries, $user->country, ['class' => 'form-control', 'placeholder' => 'Country', 'id' => 'country' ]); ?>

                        </div>

                        <div class="form-group col-md-6 cs-gov">
                            <?php echo Form::select('governorate', $governorates, $user->governorate, ['class' => 'form-control', 'placeholder' => 'Governorate']); ?>

                        </div>

                        <div class="form-group col-md-6 other-gov">
                            <?php echo Form::text('other_governorate', null, ['class' => 'form-control', 'placeholder' => 'Governorate']); ?>

                            <i class="careerfy-icon careerfy-edit"></i>
                        </div>

                        <div class="form-group col-md-6">
                            <div class="combo-select-dropdown">
                                <ul class="select-list-group" id="ComboSelect3">
                                    <li class="select-lg-dropdown">
                                        <input type="text" class="select-list-group-search" name="affiliation" placeholder="Affiliation " value="<?php echo e($user->affiliation); ?>" />
                                        <ul class="select-list-group-list" data-toggle="false">
                                            <?php $__currentLoopData = $affiliations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="select-list-group-list-item" data-display="true" data-highlight="false"><?php echo e($item); ?></li> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        </li>
                                </ul>
                            </div>
                        </div>

                        <div class="form-group col-md-6">
                            <div class="combo-select-dropdown">
                                <ul class="select-list-group" id="ComboSelect">
                                    <li class="select-lg-dropdown">
                                        <input type="text" name="speciality" class="select-list-group-search" placeholder="Speciality" value="<?php echo e($user->speciality); ?>"/>
                                        <ul class="select-list-group-list" data-toggle="false">
                                            <?php $__currentLoopData = $specialites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="select-list-group-list-item" data-display="true" data-highlight="false"><?php echo e($item); ?></li> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        </li>
                                </ul>
                            </div>
                        </div>
              

                        <div class="m-b-15 m-t-15 col-md-12">
                            <div class="terms-priv-chek-con">
                                <p>
                                    <?php echo Form::checkbox('accept_newsletter_emails', true, null, ['id' => 'accept_newsletter_emails']); ?> <label for="accept_newsletter_emails"> I consent to receiving Newsletters emails</label>
                                </p>
                            </div>
                        </div>
                        <div class="m-b-15 m-t-15 col-md-12">
                            <?php echo Form::submit('Update profile', ['class' => 'btn btn-primary pull-left']); ?>

                        </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- Main Section -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/profile/dashboard.blade.php ENDPATH**/ ?>