<?php $__env->startSection('meta'); ?>

   <title> Login - <?php echo e($general_info[0]->tagline); ?> </title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Main Section -->
<div class="careerfy-main-section careerfy-about-text-full">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 careerfy-typo-wrap">
                <div class="jobsearch-login-box">
                    <div id="exTab1">
                        <div class="div-signup">
                            <div class="careerfy-services-classic">
                                <span><i class="careerfy-icon careerfy-user-1"></i></span>
                            </div>
                            <h3>Login to your account</h3>

                        </div>
                        <div class="cs-msgs">
                            <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <form method="POST" action="<?php echo e(route('postSignin')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="careerfy-box-title careerfy-box-title-sub">
                                <span>Sign In</span>
                            </div>
                            <div id="login_form" class="careerfy-user-form">
                                <ul>
                                    <li>
                                        <label>Email Address:</label>
                                        <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Enter Your Email Address">
                                        <i class="careerfy-icon careerfy-mail"></i>
                                       
                                    </li>
                                    
                                    <li>
                                        <label>Password:</label>
                                        <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Enter Password">
                                        <i class="careerfy-icon careerfy-multimedia"></i>
                                        
                                    </li>
                                    
                                    <li>
                                        <input type="submit" value="Sign In">
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                                <div class="careerfy-user-form-info">
                                    <p><?php if(Route::has('password.request')): ?><a href="<?php echo e(route('password.request')); ?>">Forgot Password?</a> <?php endif; ?>| <a href="<?php echo e(route('register')); ?>">Sign Up</a></p>
                                    <div class="careerfy-checkbox">
                                        <input type="checkbox" id="r10" name="rr" />
                                        <label for="r10"><span></span> Remember Password</label>
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Main Section -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/auth/login.blade.php ENDPATH**/ ?>