<?php if(@$records->hasPages()): ?>
<?php
$currentRequest = '';
foreach (request()->except('page') as $key => $value) {
    try {
        //code...
        $currentRequest .= '&'.$key.'='.$value;
    } catch (\Throwable $th) {
        foreach ($value as  $val) {
            # code...
            $currentRequest .= '&'.$key.'%5B%5D='.$val;
        }
            // dd($currentRequest, request()->except('page'), $key, $value, request());
            //throw $th;
        }
    }
?>
<!-- Main Section -->
<div class="careerfy-main-section careerfy-parallex-full articles-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12 careerfy-typo-wrap">
                <div class="careerfy-pagination-blog">
                    <ul class="page-numbers">

                        <li><a class="prev page-numbers" href="<?php echo e($records->previousPageUrl().$currentRequest); ?>"><span><i class="careerfy-icon careerfy-arrows4"></i></span></a></li>

                        <?php $__currentLoopData = $records->links()->elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $array): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <?php if($array != '...'): ?>
                            
                                <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <?php if(request('page',1)==$key): ?>
                                        <span class="page-numbers current"><?php echo e($key); ?></span>
                                    <?php else: ?>
                                        <a class="page-numbers" href="<?php echo e($url . $currentRequest); ?>"><?php echo e($key); ?></a>
                                    <?php endif; ?>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php else: ?>
                                <li class="page-numbers"><b>...</b></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <li><a class="next page-numbers" href="<?php echo e($records->nextPageUrl().$currentRequest); ?>"><span><i class="careerfy-icon careerfy-arrows4"></i></span></a></li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Main Section -->
<?php endif; ?>

<?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/partials/_pagination.blade.php ENDPATH**/ ?>