<?php $__env->startSection('meta'); ?>

<title> <?php echo e(ucfirst($data['post_type'][0])); ?> - <?php echo e($general_info[0]->tagline); ?>  </title>

<meta name="title" content="<?php echo e($data['page']->meta_title ?? ''); ?>">
<meta name="description" content="<?php echo e($data['page']->meta_desc ?? ''); ?>">
<meta name="keywords" content="<?php echo e($data['page']->meta_keywords ?? ''); ?>">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<?php if(Request::is('all-videos') || Request::is('videos')): ?>
<!-- Main Section -->
<div class="careerfy-main-section careerfy-counter-full topics-section">
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="videos-filter categ-title">
                    <h2 class="cntr-title"><?php echo e($data['page']->sections->first()->title ?? ''); ?> <span><?php echo e($data['page']->sections->first()->subtitle ?? ''); ?></span></h2>
                    <p class="cntr-p"><?php echo $data['page']->sections->first()->content ??''; ?></p>
                    <div class="clearfix"></div>
                    <?php if(count($data['categories'])): ?>
                    <div class="row">
                            <div class="col-md-3"></div>
                            <div class="col-md-6">
                                <?php echo Form::open(['route' => [ 'searchCategory', $data['posts'][0]->post_type ], 'method' => 'GET', 'id' => 'select_category']); ?>

                                <div class="form-group">
                                    <?php echo Form::select('category', $data['other-categories'], null, ['class' => 'form-control', 'id' => 'category', 'placeholder' => 'Select a category'] ); ?>

                                </div>
                                <?php echo Form::close(); ?>

                            </div>
                            <div class="col-md-3"></div>
                            <div class="clearfix"></div>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="clearfix"></div>
                <?php echo $__env->make('partials._posts_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <hr style="margin-top: 40px;">
                <?php $__currentLoopData = $data['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($category->posts)): ?>
                <div class="articles-section">
                    <div class="row">
                        <h2 class="cntr-title"><?php echo e($category->title ?? ''); ?></h2>
                        <div class="articles-box ">
                            <div class="videos-only">

                                <?php $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 col-sm-6 col-xs-12 ">
                                    
                                    <div class="article-item">
                                        <div class="article-tags">
                                            <div class="video-thumbnail pos-rltv">
                                                <a href="<?php echo e($post->post_type.'/'.$post->slug); ?>">
                                                    <?php $__currentLoopData = $post->postmeta->where('meta_key', '_featured_image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <img src="<?php echo e(asset('uploads/'.$value->meta_value )); ?>" alt="<?php echo e($value->meta_value); ?>">
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(!count($post->postmeta->where('meta_key', '_featured_image')) ): ?>
                                                    <img src="<?php echo e(asset('uploads/d-post.jpeg')); ?>" alt="oncologyme">
                                                    <?php endif; ?>
                                                    <img class="pos-abslt" src="<?php echo e(asset('front-assets/img/play.png')); ?>">
                                                </a>
                                            </div>
                                            <?php $__currentLoopData = $post->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>"><?php echo e($topic->title ?? ''); ?></a></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                                        </div>
                                        <div class="clearfix"></div>
                                        <h2><a href="<?php echo e($post->post_type.'/'.$post->slug); ?>"><?php echo e(implode(' ', array_slice(explode(' ', $post->title), 0, 10))); ?><?php if( str_word_count($post->title) > 10 ): ?>...<?php endif; ?></a></h2>
                                        <h4>
                                            <span> <?php echo e($post->author ?? ''); ?> </span>
            
                                            <text><?php if($post->author): ?> &nbsp;/&nbsp; <?php endif; ?><span> <?php echo e($post->created_at->format('M d, Y') ?? ''); ?> </span></text>
            
                                        </h4>
                                    </div>
                                    
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <hr style="margin-top: 40px;">  
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(!count($data['categories'])): ?>
                <div class="articles-section">
                    <div class="row">
                        <div class="articles-box ">
                            <div class="videos-only">
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 col-sm-6 col-xs-12 ">
                                    <div class="article-item">
                                        <div class="article-tags">
                                            <div class="video-thumbnail pos-rltv">
                                                <a href="<?php echo e($post->post_type.'/'.$post->slug); ?>">
                                                    <?php $__currentLoopData = $post->postmeta->where('meta_key', '_featured_image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <img src="<?php echo e(asset('uploads/'.$value->meta_value )); ?>" alt="<?php echo e($value->meta_value); ?>">
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(!count($post->postmeta->where('meta_key', '_featured_image')) ): ?>
                                                    <img src="<?php echo e(asset('uploads/d-post.jpeg')); ?>" alt="oncologyme">
                                                    <?php endif; ?>
                                                    <img class="pos-abslt" src="<?php echo e(asset('front-assets/img/play.png')); ?>">
                                                </a>
                                            </div>
                                            <?php $__currentLoopData = $post->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>"><?php echo e($topic->title ?? ''); ?></a></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                                        </div>
                                        <div class="clearfix"></div>
                                        <h2><a href="<?php echo e($post->post_type.'/'.$post->slug); ?>"><?php echo e(implode(' ', array_slice(explode(' ', $post->title), 0, 10))); ?><?php if( str_word_count($post->title) > 10 ): ?>...<?php endif; ?></a></h2>
                                        <h4>
                                            <span> <?php echo e($post->author ?? ''); ?> </span>
            
                                            <text><?php if($post->author): ?> &nbsp;/&nbsp; <?php endif; ?><span> <?php echo e($post->created_at->format('M d, Y') ?? ''); ?> </span></text>
            
                                        </h4>
                                    </div>
                                    
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<?php else: ?>

<!-- Main Section -->
<div class="careerfy-main-section careerfy-counter-full topics-section">
    <div class="container">
        <div class="row">
            <?php if(count($highlights) || count($latest_news) || count($top_banners) || count($bottom_banners)): ?>
            <div class="col-md-8">
            <?php else: ?>
            <div class="col-md-12">
            <?php endif; ?>
                <?php echo $__env->make('partials._posts_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="m-t-20"></div>
                <div class="careerfy-typo-wrap categ-title pos-rltv">
                    <h3><span><?php echo e(ucfirst($data['posts'][0]->post_type) ?? ''); ?></span></h3>
                    <?php if(count($data['other-categories'])): ?>
                        <?php echo Form::open(['route' => [ 'searchCategory', $data['posts'][0]->post_type ], 'method' => 'GET', 'class' => 'all-category', 'id' => 'select_category']); ?>

                        <div class="form-group">
                            <?php echo Form::select('category', $data['other-categories'], null, ['class' => 'form-control', 'id' => 'category', 'placeholder' => 'Select a category'] ); ?>

                        </div>
                        <?php echo Form::close(); ?>

                    <?php endif; ?>
                </div>

                <?php if(Request::is('all-podcasts')): ?> <div class="articles-section cs-all-podcasts"> <?php endif; ?>
                <div class="articles-box">

                    <div class="articles-only">
                    
                    <?php $__currentLoopData = $data['posts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if(Request::is('all-podcasts')): ?>
                    <div class="article-item">

                        <div class="article-img-text combined-txt-img">

                            <?php $__currentLoopData = $post->postmeta->where('meta_key', '_featured_image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset('uploads/'.$value->meta_value )); ?>" alt="<?php echo e($value->meta_value); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="new-post-sec">

                                <div class="clearfix"></div>
                                <div class="article-tags">
                                    <?php $__currentLoopData = $post->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span><a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>"><?php echo e($topic->title ?? ''); ?></a></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <h2><a href="<?php echo e('/'.$post->post_type.'/'.$post->slug); ?>"><?php echo e($post->title ?? ''); ?></a></h2>

                                <p><?php echo e(implode(' ', array_slice(explode(' ', $post->excerpt), 0, 20))); ?><?php if( str_word_count($post->excerpt) > 20 ): ?>...<?php endif; ?></p>
                                <div class="podcast-link">
                                    <a href="<?php echo e('/'.$post->post_type.'/'.$post->slug); ?>">Listen now <i class="fa fa-headphones"></i></a>

                                </div>
                            </div>
                        </div>
                    </div>

                    <?php else: ?>
                    <div class="article-item">
                        <div class="article-tags">
                            <?php $__currentLoopData = $post->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span><a href="<?php echo e(route('showTopic', $topic->slug ?? '')); ?>"><?php echo e($topic->title ?? ''); ?></a></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="clearfix"></div>
                        <h2><a href="<?php echo e('/'.$post->post_type.'/'.$post->slug); ?>"><?php echo e($post->title ?? ''); ?></a></h2>
                        <h4>
                            <span> <?php echo e($post->author ?? ''); ?> </span>

                            <text><?php if($post->author): ?> &nbsp;/&nbsp; <?php endif; ?><span> <?php echo e($post->created_at->format('M d, Y') ?? ''); ?> </span></text>

                        </h4>
                        <div class="article-img-text">
                            
                            <p><?php echo e(implode(' ', array_slice(explode(' ', $post->excerpt), 0, 20))); ?><?php if( str_word_count($post->excerpt) > 20 ): ?>...<?php endif; ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>
                <?php if(Request::is('all-podcasts')): ?> </div> <?php endif; ?>

            </div>

            <!-- sidebar -->
            <?php echo $__env->make('partials._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
</div>
<!-- Main Section -->



<?php echo $__env->make('partials._pagination', ['records' => $data['posts']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/abdelrahmantawfek/Desktop/work/clients/Moustafa/oncologyme/development/OncologyMe/resources/views/frontend/posts.blade.php ENDPATH**/ ?>